
import axios from 'axios';

const BASE_URL = {
  dev: "http://localhost:3004/",
  prod: "mentor-mee",
}

export interface BaseEntity {
  id: string;
}

const api = axios.create({
  baseURL: BASE_URL.dev,
  timeout: 1000,
  headers: {'X-Custom-Header': 'foobar'}
});

const load = (getUrl: Function) => () => api.get(`${getUrl()}`)

const find = (getUrlWithId: Function) => (id: string) => api.get(`${getUrlWithId(id)}`)

const create = (getUrl: Function) => (entity: BaseEntity) => api.post(`${getUrl()}`, entity)

const update = (getUrlWithId: Function) => (entity: BaseEntity) => api.patch(`${getUrlWithId(entity.id)}`, entity)

const remove = (getUrlWithId: Function) => (id: string) => api.delete(`${getUrlWithId(id)}`)

export const baseAPI = (getUrl: Function, getUrlWithId: Function) => ({
  load: load(getUrl),
  find: find(getUrlWithId),
  create: create(getUrl),
  update: update(getUrlWithId),
  remove: remove(getUrlWithId)
}) 
  