
import { baseAPI } from './data.conf';

const getUrl = () => `mentors/`;

const getUrlWithId = (id: string) => `mentors/${id}`;

export const mentorsAPI = baseAPI(getUrl, getUrlWithId);
  