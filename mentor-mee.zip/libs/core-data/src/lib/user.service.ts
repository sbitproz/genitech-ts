
import { baseAPI } from './data.conf';

const getUrl = () => `users/`;

const getUrlWithId = (id: string) => `users/${id}`;

export const usersAPI = baseAPI(getUrl, getUrlWithId);
  