
import { baseAPI } from './data.conf';

const getUrl = () => `sprints/`;

const getUrlWithId = (id: string) => `sprints/${id}`;

export const sprintsAPI = baseAPI(getUrl, getUrlWithId);
  