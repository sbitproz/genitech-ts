
import { baseAPI } from './data.conf';

const getUrl = () => `mentees/`;

const getUrlWithId = (id: string) => `mentees/${id}`;

export const menteesAPI = baseAPI(getUrl, getUrlWithId);
  