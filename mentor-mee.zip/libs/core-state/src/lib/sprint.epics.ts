
// Sprint Epic
export const sprintEpic = 'epic';
// export const sprintEpic$ = actions$ => actions$.pipe(
//   ofType(SprintsActions.labelSprint), // Trigger Event
//   pessimisticUpdate({
//     run: (action) => this.sprintsService.label(action.sprint).pipe(
//       map((sprint: Sprint) => SprintsActions.labelSprintSuccess({ sprint })) // Completion Event
//     ),
//     onError: (action, error) => SprintsActions.{label}SprintFailure({ error }) // Completion Event
//   })
// );
  