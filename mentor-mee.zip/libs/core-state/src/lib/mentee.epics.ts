
// Mentee Epic
export const menteeEpic = 'epic';
// export const menteeEpic$ = actions$ => actions$.pipe(
//   ofType(MenteesActions.labelMentee), // Trigger Event
//   pessimisticUpdate({
//     run: (action) => this.menteesService.label(action.mentee).pipe(
//       map((mentee: Mentee) => MenteesActions.labelMenteeSuccess({ mentee })) // Completion Event
//     ),
//     onError: (action, error) => MenteesActions.{label}MenteeFailure({ error }) // Completion Event
//   })
// );
  