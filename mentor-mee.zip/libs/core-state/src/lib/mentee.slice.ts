
import {
  createEntityAdapter,
  createSlice,
  EntityState,
  // PayloadAction,
} from '@reduxjs/toolkit';
    
export const MENTEES_SLICE_FEATURE_KEY = 'mentees';

export interface MenteeSliceEntity {
  id: number;
}

export interface MenteeSliceState extends EntityState<MenteeSliceEntity> {
  selectedId?: string | number; // which Mentees record has been selected
  loadingStatus: 'not loaded' | 'loading' | 'loaded' | 'error';
  error?: string;
}

export const menteeSliceAdapter = createEntityAdapter<MenteeSliceEntity>();

const initialState: MenteeSliceState = menteeSliceAdapter.getInitialState({
  loadingStatus: 'not loaded',
  error: undefined,
});
  
export const menteeSlice = createSlice({
  name: MENTEES_SLICE_FEATURE_KEY,
  initialState: initialState,
  reducers: {
    add: menteeSliceAdapter.addOne,
    remove: menteeSliceAdapter.removeOne,
  },
});

export default menteeSlice.reducer
