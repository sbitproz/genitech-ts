
// User Epic
export const userEpic = 'epic';
// export const userEpic$ = actions$ => actions$.pipe(
//   ofType(UsersActions.labelUser), // Trigger Event
//   pessimisticUpdate({
//     run: (action) => this.usersService.label(action.user).pipe(
//       map((user: User) => UsersActions.labelUserSuccess({ user })) // Completion Event
//     ),
//     onError: (action, error) => UsersActions.{label}UserFailure({ error }) // Completion Event
//   })
// );
  