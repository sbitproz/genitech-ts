
import {
  createEntityAdapter,
  createSlice,
  EntityState,
  // PayloadAction,
} from '@reduxjs/toolkit';
    
export const USERS_SLICE_FEATURE_KEY = 'users';

export interface UserSliceEntity {
  id: number;
}

export interface UserSliceState extends EntityState<UserSliceEntity> {
  selectedId?: string | number; // which Users record has been selected
  loadingStatus: 'not loaded' | 'loading' | 'loaded' | 'error';
  error?: string;
}

export const userSliceAdapter = createEntityAdapter<UserSliceEntity>();

const initialState: UserSliceState = userSliceAdapter.getInitialState({
  loadingStatus: 'not loaded',
  error: undefined,
});
  
export const userSlice = createSlice({
  name: USERS_SLICE_FEATURE_KEY,
  initialState: initialState,
  reducers: {
    add: userSliceAdapter.addOne,
    remove: userSliceAdapter.removeOne,
  },
});

export default userSlice.reducer
