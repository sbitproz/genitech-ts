
import {
  createEntityAdapter,
  createSlice,
  EntityState,
  // PayloadAction,
} from '@reduxjs/toolkit';
    
export const SPRINTS_SLICE_FEATURE_KEY = 'sprints';

export interface SprintSliceEntity {
  id: number;
}

export interface SprintSliceState extends EntityState<SprintSliceEntity> {
  selectedId?: string | number; // which Sprints record has been selected
  loadingStatus: 'not loaded' | 'loading' | 'loaded' | 'error';
  error?: string;
}

export const sprintSliceAdapter = createEntityAdapter<SprintSliceEntity>();

const initialState: SprintSliceState = sprintSliceAdapter.getInitialState({
  loadingStatus: 'not loaded',
  error: undefined,
});
  
export const sprintSlice = createSlice({
  name: SPRINTS_SLICE_FEATURE_KEY,
  initialState: initialState,
  reducers: {
    add: sprintSliceAdapter.addOne,
    remove: sprintSliceAdapter.removeOne,
  },
});

export default sprintSlice.reducer
