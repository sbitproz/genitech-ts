
// Mentor Epic
export const mentorEpic = 'epic';
// export const mentorEpic$ = actions$ => actions$.pipe(
//   ofType(MentorsActions.labelMentor), // Trigger Event
//   pessimisticUpdate({
//     run: (action) => this.mentorsService.label(action.mentor).pipe(
//       map((mentor: Mentor) => MentorsActions.labelMentorSuccess({ mentor })) // Completion Event
//     ),
//     onError: (action, error) => MentorsActions.{label}MentorFailure({ error }) // Completion Event
//   })
// );
  