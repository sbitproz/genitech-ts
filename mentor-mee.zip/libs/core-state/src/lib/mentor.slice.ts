
import {
  createEntityAdapter,
  createSlice,
  EntityState,
  // PayloadAction,
} from '@reduxjs/toolkit';
    
export const MENTORS_SLICE_FEATURE_KEY = 'mentors';

export interface MentorSliceEntity {
  id: number;
}

export interface MentorSliceState extends EntityState<MentorSliceEntity> {
  selectedId?: string | number; // which Mentors record has been selected
  loadingStatus: 'not loaded' | 'loading' | 'loaded' | 'error';
  error?: string;
}

export const mentorSliceAdapter = createEntityAdapter<MentorSliceEntity>();

const initialState: MentorSliceState = mentorSliceAdapter.getInitialState({
  loadingStatus: 'not loaded',
  error: undefined,
});
  
export const mentorSlice = createSlice({
  name: MENTORS_SLICE_FEATURE_KEY,
  initialState: initialState,
  reducers: {
    add: mentorSliceAdapter.addOne,
    remove: mentorSliceAdapter.removeOne,
  },
});

export default mentorSlice.reducer
